# Pre Alpha v1.0.1
### [v1.0.1] [For Lethal Company v45] Lethal CMod is a modpack with over +30 Mods!

#### Features:
- Increases the difficulty of vanilla Lethal Comapany!
- Ideal for 1-8 players or more!
- Adds new content to the game!
- Adds quality of life content!
- And much more!

---
### Weekly Updates!
#### On new version releases, we recommend reinstalling the modpack!
Just downlaod it from 
<a href="https://thunderstore.io/package/Lethal_CMod/?section=modpacks" target="_blank">Thunderstore</a>
or from our GitHub website.

#### GitHub coming soon!

---
### Update Calendar

- ~~25.12.2023 [v1.0.1]~~

- 29.12.2023 [v1.1.0]

- #### 5.1.2024 Early Access Update [v1.2.0]

- #### More coming soon!

---
### Update Log
<details>
<summary>Click here to view all changes in order.</summary>

### v1.0.0
```
- Release
```

### v1.0.1
```
Fixes
- Fixed TAB problem with terminal

Removed
- Glowstick
- Terminal_Clock
- AdditionalSuits
```
</details>

---