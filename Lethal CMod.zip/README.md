# Pre Alpha v1.1.0
### [v1.1.0] [For Lethal Company v45] Lethal CMod is a modpack with over +30 Mods!

<img src="https://cdn.discordapp.com/attachments/1188859656437760111/1188863155930140886/image.png?ex=659c1218&is=65899d18&hm=aabdbc36b49ba4be4024aaddde407668f73501ab62f7de9e4f401371dc8566d9&">

---
### *Features*
- Increases the difficulty of Lethal Comapany!

- Ideal for 1-8 players or more!

- Adds new content to the game!

- Adds quality of life content!

- And much more!

---
### *Weekly Updates*!
#### On new version releases, we recommend reinstalling the modpack!
Just downlaod it from 
<a href="https://thunderstore.io/package/Lethal_CMod/?section=modpacks" target="_blank">Thunderstore</a>
or from our <a href="https://github.com/LethalCMod">GitHub</a> website.

---
### *Update Calendar*

- ~~25.12.2023 [v1.0.1] Hotfix~~

- ~~25.12.2023 [v1.0.2] Hotfix~~

- ~~25.12.2023 [v1.1.0] Patch 1~~

- 29.12.2023 [v1.2.0] Patch 2

- #### 5.1.2024 [v1.3.0] Early Access Update

- #### More coming soon!

---
### *Update Log*
<details>
<summary>Click here to view all changes in order.</summary>

### v1.1.0
```
Fixes
- Fixed crash when start a game
- Fixed sound bug
- Fixed some issues with Suits
- Fixed some other issues

Features
- Added AllTheScrap
- Added Aquatis
- Added MobDrops
- Added PushCompany
```

### v1.0.2
```
Fixes
- Fixed README.md file
- Fixed some other issues

Improvements
- Added GitHub link

```

### v1.0.1
```
Fixes
- Fixed TAB problem with terminal

Removed
- Glowstick
- Terminal_Clock
- AdditionalSuits
```

### v1.0.0
```
- Release
```

</details>

---